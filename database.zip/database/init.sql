CREATE DATABASE IF NOT EXISTS subway DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE subway;

DROP TABLE IF EXISTS connections;
DROP TABLE IF EXISTS line_stations;
DROP TABLE IF EXISTS stations;
DROP TABLE IF EXISTS lines;

CREATE TABLE lines (
    line_id VARCHAR(20) PRIMARY KEY,
    line_name VARCHAR(50) NOT NULL,
    direction VARCHAR(100) NOT NULL
);

CREATE TABLE stations (
    station_id VARCHAR(50) PRIMARY KEY,
    station_name VARCHAR(50) NOT NULL
);

CREATE TABLE line_stations (
    line_id VARCHAR(20),
    station_id VARCHAR(50),
    station_order INT NOT NULL,
    PRIMARY KEY (line_id, station_id),
    FOREIGN KEY (line_id) REFERENCES lines(line_id),
    FOREIGN KEY (station_id) REFERENCES stations(station_id)
);

CREATE TABLE connections (
    connection_id INT AUTO_INCREMENT PRIMARY KEY,
    from_station_id VARCHAR(50),
    to_station_id VARCHAR(50),
    line_id VARCHAR(20),
    distance INT DEFAULT 1,
    FOREIGN KEY (from_station_id) REFERENCES stations(station_id),
    FOREIGN KEY (to_station_id) REFERENCES stations(station_id),
    FOREIGN KEY (line_id) REFERENCES lines(line_id)
);

INSERT INTO lines (line_id, line_name, direction) VALUES 
('10', '地铁10号线', '内环'),
('4', '地铁4号线', '安河桥北方向'),
('4_s', '地铁4号线', '天宫院方向'),
('13', '地铁13号线', '西直门方向'),
('13_e', '地铁13号线', '东直门方向');

INSERT INTO stations (station_id, station_name) VALUES 
('zhichunlu', '知春路'),
('zhichunli', '知春里'),
('haidianhuangzhuang', '海淀黄庄'),
('zhongguancun', '中关村'),
('xituancheng', '西土城'),
('wudaokou', '五道口'),
('qinghuadongluxikou', '清华东路西口'),
('liangxiang', '良乡'),
('caishikou', '菜市口'),
('xidan', '西单'),
('xi\'anmen', '西四'),
('ping\'anli', '平安里'),
('xizhimen', '西直门'),
('beijingxi', '北京西站');

INSERT INTO line_stations (line_id, station_id, station_order) VALUES 
('10', 'zhichunlu', 1),
('10', 'xituancheng', 2),
('10', 'wudaokou', 3),
('10', 'qinghuadongluxikou', 4),
('10', 'haidianhuangzhuang', 5),
('10', 'zhichunli', 6),
('10', 'zhongguancun', 7),
('4', 'zhongguancun', 1),
('4', 'haidianhuangzhuang', 2),
('4', 'caishikou', 3),
('4', 'xidan', 4),
('4', 'xi\'anmen', 5),
('4', 'ping\'anli', 6),
('4', 'xizhimen', 7),
('13', 'zhichunlu', 1),
('13', 'xizhimen', 2),
('13', 'beijingxi', 3);

INSERT INTO connections (from_station_id, to_station_id, line_id, distance) VALUES 
('zhichunlu', 'xituancheng', '10', 1),
('xituancheng', 'zhichunlu', '10', 1),
('xituancheng', 'wudaokou', '10', 1),
('wudaokou', 'xituancheng', '10', 1),
('wudaokou', 'qinghuadongluxikou', '10', 1),
('qinghuadongluxikou', 'wudaokou', '10', 1),
('qinghuadongluxikou', 'haidianhuangzhuang', '10', 1),
('haidianhuangzhuang', 'qinghuadongluxikou', '10', 1),
('haidianhuangzhuang', 'zhichunli', '10', 1),
('zhichunli', 'haidianhuangzhuang', '10', 1),
('zhichunli', 'zhongguancun', '10', 1),
('zhongguancun', 'zhichunli', '10', 1),
('zhongguancun', 'haidianhuangzhuang', '4', 1),
('haidianhuangzhuang', 'zhongguancun', '4', 1),
('haidianhuangzhuang', 'caishikou', '4', 2),
('caishikou', 'haidianhuangzhuang', '4', 2),
('caishikou', 'xidan', '4', 1),
('xidan', 'caishikou', '4', 1),
('xidan', 'xi\'anmen', '4', 1),
('xi\'anmen', 'xidan', '4', 1),
('xi\'anmen', 'ping\'anli', '4', 1),
('ping\'anli', 'xi\'anmen', '4', 1),
('ping\'anli', 'xizhimen', '4', 1),
('xizhimen', 'ping\'anli', '4', 1),
('zhichunlu', 'xizhimen', '13', 2),
('xizhimen', 'zhichunlu', '13', 2),
('xizhimen', 'beijingxi', '13', 1),
('beijingxi', 'xizhimen', '13', 1);

CREATE INDEX idx_station_name ON stations(station_name);
CREATE INDEX idx_line_stations_line ON line_stations(line_id);
CREATE INDEX idx_connections_from ON connections(from_station_id);
CREATE INDEX idx_connections_to ON connections(to_station_id);