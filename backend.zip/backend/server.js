const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
const path = require('path');
const subwayData = require('./data/subwayData');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));

const dbConfig = {
    host: 'localhost',
    user: 'root',
    password: 'M-c298014',
    database: 'subway'
};

let connection;

async function initDatabase() {
    let tempConn;
    try {
        tempConn = await mysql.createConnection({
            host: dbConfig.host,
            user: dbConfig.user,
            password: dbConfig.password
        });
        
        await tempConn.execute('CREATE DATABASE IF NOT EXISTS subway DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
        await tempConn.end();
        
        connection = await mysql.createConnection(dbConfig);
        
        await connection.execute('DROP TABLE IF EXISTS `connections`');
        await connection.execute('DROP TABLE IF EXISTS `line_stations`');
        await connection.execute('DROP TABLE IF EXISTS `stations`');
        await connection.execute('DROP TABLE IF EXISTS `lines`');
        
        await connection.execute('CREATE TABLE IF NOT EXISTS `lines` (`line_id` VARCHAR(20) PRIMARY KEY, `line_name` VARCHAR(50) NOT NULL, `direction` VARCHAR(100) NOT NULL)');
        await connection.execute('CREATE TABLE IF NOT EXISTS `stations` (`station_id` VARCHAR(50) PRIMARY KEY, `station_name` VARCHAR(50) NOT NULL)');
        await connection.execute('CREATE TABLE IF NOT EXISTS `line_stations` (`line_id` VARCHAR(20), `station_id` VARCHAR(50), `station_order` INT NOT NULL, PRIMARY KEY (`line_id`, `station_id`))');
        await connection.execute('CREATE TABLE IF NOT EXISTS `connections` (`connection_id` INT AUTO_INCREMENT PRIMARY KEY, `from_station_id` VARCHAR(50), `to_station_id` VARCHAR(50), `line_id` VARCHAR(20), `distance` INT DEFAULT 1)');
        
        for (const line of subwayData.lines) {
            await connection.execute('INSERT INTO `lines` (`line_id`, `line_name`, `direction`) VALUES (?, ?, ?)', line);
        }
        console.log('线路数据插入完成');
        
        for (const station of subwayData.stations) {
            await connection.execute('INSERT INTO `stations` (`station_id`, `station_name`) VALUES (?, ?)', station);
        }
        console.log('站点数据插入完成');
        
        for (const ls of subwayData.lineStations) {
            await connection.execute('INSERT INTO `line_stations` (`line_id`, `station_id`, `station_order`) VALUES (?, ?, ?)', ls);
        }
        console.log('线路站点关系插入完成');
        
        const lineGroups = {};
        subwayData.lineStations.forEach(([lineId, stationId, order]) => {
            if (!lineGroups[lineId]) lineGroups[lineId] = [];
            lineGroups[lineId].push({ stationId, order });
        });
        
        for (const lineId of Object.keys(lineGroups)) {
            const stations = lineGroups[lineId].sort((a, b) => a.order - b.order);
            for (let i = 0; i < stations.length - 1; i++) {
                await connection.execute('INSERT INTO `connections` (`from_station_id`, `to_station_id`, `line_id`, `distance`) VALUES (?, ?, ?, 1)', [stations[i].stationId, stations[i+1].stationId, lineId]);
                await connection.execute('INSERT INTO `connections` (`from_station_id`, `to_station_id`, `line_id`, `distance`) VALUES (?, ?, ?, 1)', [stations[i+1].stationId, stations[i].stationId, lineId]);
            }
        }
        console.log('连接数据插入完成');
        
        console.log('数据库初始化完成');
        console.log('数据库连接成功');
    } catch (error) {
        console.error('数据库初始化失败:', error);
        if (tempConn) await tempConn.end();
        process.exit(1);
    }
}

class SubwaySystem {
    constructor() {
        this.stations = new Map();
        this.lines = new Map();
        this.connections = new Map();
    }

    async loadData() {
        try {
            const [lines] = await connection.execute('SELECT * FROM `lines`');
            const [stations] = await connection.execute('SELECT * FROM `stations`');
            const [lineStations] = await connection.execute('SELECT * FROM `line_stations`');
            const [connections] = await connection.execute('SELECT * FROM `connections`');

            lines.forEach(line => {
                this.lines.set(line.line_id, { name: line.line_name, direction: line.direction });
            });

            stations.forEach(station => {
                this.stations.set(station.station_id, station.station_name);
            });

            connections.forEach(conn => {
                if (!this.connections.has(conn.from_station_id)) {
                    this.connections.set(conn.from_station_id, []);
                }
                this.connections.get(conn.from_station_id).push({
                    to: conn.to_station_id,
                    line: conn.line_id,
                    distance: conn.distance
                });
            });

            this.lineStationsMap = new Map();
            lineStations.forEach(ls => {
                if (!this.lineStationsMap.has(ls.line_id)) {
                    this.lineStationsMap.set(ls.line_id, []);
                }
                this.lineStationsMap.get(ls.line_id).push({
                    station_id: ls.station_id,
                    order: ls.station_order
                });
            });

            for (const [lineId, stations] of this.lineStationsMap) {
                stations.sort((a, b) => a.order - b.order);
            }

            console.log('数据加载完成');
        } catch (error) {
            console.error('数据加载失败:', error);
        }
    }

    getLines() {
        const lineNames = new Set();
        this.lines.forEach((info, lineId) => {
            lineNames.add(info.name);
        });
        return Array.from(lineNames);
    }

    getStationsByLine(lineName) {
        const result = [];
        for (const [lineId, info] of this.lines) {
            if (info.name === lineName) {
                const stations = this.lineStationsMap.get(lineId);
                if (stations) {
                    stations.forEach(ls => {
                        result.push({
                            station_id: ls.station_id,
                            station_name: this.stations.get(ls.station_id),
                            order: ls.order
                        });
                    });
                    result.sort((a, b) => a.order - b.order);
                    return result;
                }
            }
        }
        return result;
    }

    getLinesByStation(stationName) {
        const stationId = this.getStationIdByName(stationName);
        if (!stationId) return [];

        const lines = new Set();
        for (const [lineId, stations] of this.lineStationsMap) {
            const hasStation = stations.some(ls => ls.station_id === stationId);
            if (hasStation) {
                lines.add(this.lines.get(lineId).name);
            }
        }
        return Array.from(lines);
    }

    getStationIdByName(name) {
        for (const [id, stationName] of this.stations) {
            if (stationName === name) return id;
        }
        return null;
    }

    async findShortestPath(startName, endName) {
        const startId = this.getStationIdByName(startName);
        const endId = this.getStationIdByName(endName);

        if (!startId || !endId) {
            return { error: '站点不存在' };
        }

        const distances = new Map();
        const previous = new Map();
        const visited = new Set();

        this.stations.forEach((_, id) => {
            distances.set(id, Infinity);
            previous.set(id, null);
        });

        distances.set(startId, 0);

        while (visited.size < this.stations.size) {
            let minDist = Infinity;
            let current = null;

            for (const [id, dist] of distances) {
                if (!visited.has(id) && dist < minDist) {
                    minDist = dist;
                    current = id;
                }
            }

            if (current === null || minDist === Infinity) break;
            if (current === endId) break;

            visited.add(current);

            const neighbors = this.connections.get(current) || [];
            for (const neighbor of neighbors) {
                const alt = distances.get(current) + neighbor.distance;
                if (alt < distances.get(neighbor.to)) {
                    distances.set(neighbor.to, alt);
                    previous.set(neighbor.to, { station: current, line: neighbor.line });
                }
            }
        }

        if (distances.get(endId) === Infinity) {
            return { error: '无法到达' };
        }

        const path = [];
        let current = endId;
        while (current !== null) {
            const prev = previous.get(current);
            if (prev) {
                path.unshift({
                    station_id: current,
                    station_name: this.stations.get(current),
                    line: prev.line,
                    line_name: this.lines.get(prev.line).name
                });
            } else {
                path.unshift({
                    station_id: current,
                    station_name: this.stations.get(current),
                    line: null,
                    line_name: null
                });
            }
            current = prev ? prev.station : null;
        }

        if (path.length > 0 && path[0].line === null) {
            const firstNeighbor = this.connections.get(startId)?.[0];
            if (firstNeighbor) {
                path[0].line = firstNeighbor.line;
                path[0].line_name = this.lines.get(firstNeighbor.line).name;
            }
        }

        let transfers = [];
        for (let i = 1; i < path.length; i++) {
            if (path[i].line !== path[i-1].line) {
                transfers.push({
                    station: path[i].station_name,
                    from_line: path[i-1].line_name,
                    to_line: path[i].line_name
                });
            }
        }

        return {
            count: path.length,
            path: path.map(p => ({
                station_name: p.station_name,
                line_name: p.line_name,
                is_transfer: transfers.some(t => t.station === p.station_name)
            })),
            transfers
        };
    }

    async findLeastTransfers(startName, endName) {
        const startId = this.getStationIdByName(startName);
        const endId = this.getStationIdByName(endName);

        if (!startId || !endId) {
            return { error: '站点不存在' };
        }

        const queue = [];
        const visited = new Map();

        queue.push({ station: startId, line: null, transfers: 0, path: [{ station_id: startId, station_name: this.stations.get(startId), line: null }] });
        visited.set(`${startId}-null`, 0);

        while (queue.length > 0) {
            queue.sort((a, b) => a.transfers - b.transfers);
            const current = queue.shift();

            if (current.station === endId) {
                const path = current.path.map(p => ({
                    station_name: p.station_name,
                    line_name: p.line ? this.lines.get(p.line).name : null,
                    is_transfer: p.line !== null && current.path[current.path.indexOf(p) - 1]?.line !== p.line
                }));

                let transfers = [];
                for (let i = 1; i < current.path.length; i++) {
                    if (current.path[i].line !== current.path[i-1].line) {
                        transfers.push({
                            station: current.path[i].station_name,
                            from_line: current.path[i-1].line ? this.lines.get(current.path[i-1].line).name : null,
                            to_line: this.lines.get(current.path[i].line).name
                        });
                    }
                }

                return {
                    count: current.path.length,
                    path,
                    transfers,
                    transfer_count: current.transfers
                };
            }

            const neighbors = this.connections.get(current.station) || [];
            for (const neighbor of neighbors) {
                const newTransfers = current.line !== null && current.line !== neighbor.line ? current.transfers + 1 : current.transfers;
                const key = `${neighbor.to}-${neighbor.line}`;

                if (!visited.has(key) || newTransfers < visited.get(key)) {
                    visited.set(key, newTransfers);
                    queue.push({
                        station: neighbor.to,
                        line: neighbor.line,
                        transfers: newTransfers,
                        path: [...current.path, {
                            station_id: neighbor.to,
                            station_name: this.stations.get(neighbor.to),
                            line: neighbor.line
                        }]
                    });
                }
            }
        }

        return { error: '无法到达' };
    }

    traverseAllStations(startName) {
        const startId = this.getStationIdByName(startName);
        if (!startId) {
            return { success: false, error: '站点不存在' };
        }

        const visited = new Set([startId]);
        const path = [];
        const queue = [{ stationId: startId, lineId: null, prevId: null }];
        const maxSteps = Math.min(this.stations.size * 2, 300);
        
        while (queue.length > 0 && path.length < maxSteps) {
            const { stationId, lineId, prevId } = queue.shift();
            
            path.push({
                station_id: stationId,
                station_name: this.stations.get(stationId),
                line: lineId,
                line_name: lineId ? this.lines.get(lineId).name : null
            });
            
            const neighbors = this.connections.get(stationId) || [];
            for (const neighbor of neighbors) {
                if (neighbor.to !== prevId) {
                    visited.add(neighbor.to);
                    queue.push({ 
                        stationId: neighbor.to, 
                        lineId: neighbor.line, 
                        prevId: stationId 
                    });
                }
            }
        }
        
        const stationNames = new Set(path.map(p => p.station_name).filter(Boolean));
        
        return {
            success: true,
            count: path.length,
            visited_count: stationNames.size,
            total_stations: this.stations.size,
            path: path.map(p => ({
                station_name: p.station_name || '未知站点',
                line_name: p.line_name
            }))
        };
    }
}

let subwaySystem;

app.get('/api/lines', async (req, res) => {
    try {
        const lines = subwaySystem.getLines();
        res.json({ success: true, data: lines });
    } catch (error) {
        res.json({ success: false, error: error.message });
    }
});

app.get('/api/stations', async (req, res) => {
    try {
        const stations = Array.from(subwaySystem.stations.values());
        res.json({ success: true, data: stations });
    } catch (error) {
        res.json({ success: false, error: error.message });
    }
});

app.get('/api/line/:lineName/stations', async (req, res) => {
    try {
        const lineName = decodeURIComponent(req.params.lineName);
        const stations = subwaySystem.getStationsByLine(lineName);
        res.json({ success: true, data: stations });
    } catch (error) {
        res.json({ success: false, error: error.message });
    }
});

app.get('/api/station/:stationName/lines', async (req, res) => {
    try {
        const stationName = decodeURIComponent(req.params.stationName);
        const lines = subwaySystem.getLinesByStation(stationName);
        res.json({ success: true, data: lines });
    } catch (error) {
        res.json({ success: false, error: error.message });
    }
});

app.get('/api/path/shortest', async (req, res) => {
    try {
        const { start, end } = req.query;
        const result = await subwaySystem.findShortestPath(start, end);
        res.json({ success: !result.error, ...result });
    } catch (error) {
        res.json({ success: false, error: error.message });
    }
});

app.get('/api/path/least-transfers', async (req, res) => {
    try {
        const { start, end } = req.query;
        const result = await subwaySystem.findLeastTransfers(start, end);
        res.json({ success: !result.error, ...result });
    } catch (error) {
        res.json({ success: false, error: error.message });
    }
});

app.get('/api/traverse', async (req, res) => {
    try {
        const { start } = req.query;
        const result = subwaySystem.traverseAllStations(start);
        res.json({ success: !result.error, ...result });
    } catch (error) {
        res.json({ success: false, error: error.message });
    }
});

async function startServer() {
    await initDatabase();
    subwaySystem = new SubwaySystem();
    await subwaySystem.loadData();
    
    const PORT = process.env.PORT || 3000;
    app.listen(PORT, '0.0.0.0', () => {
        console.log(`Server running on http://0.0.0.0:${PORT}`);
    });
}

startServer();