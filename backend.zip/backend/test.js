const mysql = require('mysql2/promise');

const dbConfig = {
    host: 'localhost',
    user: 'root',
    password: '514609',
    database: 'subway'
};

class ShortestPathTest {
    constructor() {
        this.stations = new Map();
        this.connections = new Map();
    }

    addStation(id, name) {
        this.stations.set(id, name);
    }

    addConnection(from, to, line, distance = 1) {
        if (!this.connections.has(from)) {
            this.connections.set(from, []);
        }
        this.connections.get(from).push({ to, line, distance });
    }

    shortestPath(startId, endId) {
        const distances = new Map();
        const previous = new Map();
        const visited = new Set();

        this.stations.forEach((_, id) => {
            distances.set(id, Infinity);
            previous.set(id, null);
        });
        distances.set(startId, 0);

        while (visited.size < this.stations.size) {
            let minDist = Infinity;
            let current = null;

            distances.forEach((dist, id) => {
                if (!visited.has(id) && dist < minDist) {
                    minDist = dist;
                    current = id;
                }
            });

            if (current === null || current === endId) break;
            visited.add(current);

            const neighbors = this.connections.get(current) || [];
            for (const neighbor of neighbors) {
                const alt = distances.get(current) + neighbor.distance;
                if (alt < distances.get(neighbor.to)) {
                    distances.set(neighbor.to, alt);
                    previous.set(neighbor.to, { station: current, line: neighbor.line });
                }
            }
        }

        return this.reconstructPath(startId, endId, previous);
    }

    reconstructPath(startId, endId, previous) {
        const path = [];
        let current = endId;

        while (current !== null) {
            path.unshift(this.stations.get(current));
            const prev = previous.get(current);
            current = prev ? prev.station : null;
        }

        if (path[0] !== this.stations.get(startId)) return null;

        return {
            count: path.length,
            path: path
        };
    }
}

async function runTests() {
    let connection;
    try {
        connection = await mysql.createConnection(dbConfig);
        console.log('数据库连接成功');

        const [stations] = await connection.execute('SELECT * FROM stations');
        const [connections] = await connection.execute('SELECT * FROM connections');

        const test = new ShortestPathTest();
        stations.forEach(s => test.addStation(s.station_id, s.station_name));
        connections.forEach(c => test.addConnection(c.from_station_id, c.to_station_id, c.line_id, c.distance));

        console.log('\n=== 测试最短路径算法 ===');
        
        const testCases = [
            { start: 'zhichunlu', end: 'zhongguancun', expected: ['知春路', '知春里', '中关村'] },
            { start: 'zhichunlu', end: 'haidianhuangzhuang', expected: ['知春路', '西土城', '五道口', '清华东路西口', '海淀黄庄'] },
            { start: 'zhongguancun', end: 'xizhimen', expected: null }
        ];

        testCases.forEach((tc, index) => {
            const result = test.shortestPath(tc.start, tc.end);
            console.log(`测试 ${index + 1}: ${tc.start} -> ${tc.end}`);
            console.log(`  结果: ${result ? JSON.stringify(result) : 'null'}`);
            if (tc.expected) {
                const passed = result && JSON.stringify(result.path) === JSON.stringify(tc.expected);
                console.log(`  期望: ${JSON.stringify(tc.expected)}`);
                console.log(`  ${passed ? '✓ 通过' : '✗ 失败'}`);
            }
            console.log();
        });

        console.log('=== 测试完成 ===');

    } catch (error) {
        console.error('测试失败:', error);
        process.exit(1);
    } finally {
        if (connection) {
            await connection.end();
        }
    }
}

runTests();